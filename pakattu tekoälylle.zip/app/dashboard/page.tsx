'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'

type Project = {
  id: string
  name: string
  city: string
  phase: string
  is_public: boolean

  location: string | null
  developer: string | null
  builder: string | null
  property_type: string | null
  apartments: number | null
  floor_area: number | null
  estimated_cost: number | null
  construction_start: string | null

  structural_design: string | null
  hvac_design: string | null
  electrical_design: string | null
  architectural_design: string | null
  geotechnical_design: string | null
  earthworks_contractor: string | null
  additional_info: string | null

  latitude: number | null
  longitude: number | null
}

export default function Dashboard() {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState<string | null>(null)

  const emptyForm = {
    name: '',
    city: '',
    phase: '',
    is_public: true,
    location: '',
    developer: '',
    builder: '',
    property_type: '',
    apartments: '',
    floor_area: '',
    estimated_cost: '',
    construction_start: '',
    structural_design: '',
    hvac_design: '',
    electrical_design: '',
    architectural_design: '',
    geotechnical_design: '',
    earthworks_contractor: '',
    additional_info: '',
  }

  const [form, setForm] = useState<any>(emptyForm)

  useEffect(() => {
    fetchProjects()
  }, [])

  async function fetchProjects() {
    const { data, error } = await supabase.from('projects').select('*')
    if (error) console.error(error)
    else setProjects(data || [])
    setLoading(false)
  }

  async function geocodeAddress(address: string) {
    if (!address) return { lat: null, lon: null }

    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
          address
        )}`
      )
      const data = await res.json()

      if (data && data.length > 0) {
        return {
          lat: parseFloat(data[0].lat),
          lon: parseFloat(data[0].lon),
        }
      }

      return { lat: null, lon: null }
    } catch (err) {
      console.error('Geocoding error:', err)
      return { lat: null, lon: null }
    }
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()

    const coords = await geocodeAddress(form.location)

    const payload = {
      ...form,
      apartments: form.apartments ? Number(form.apartments) : null,
      floor_area: form.floor_area ? Number(form.floor_area) : null,
      estimated_cost: form.estimated_cost
        ? Number(form.estimated_cost)
        : null,
      latitude: coords.lat,
      longitude: coords.lon,
    }

    if (editingId) {
      const { error } = await supabase
        .from('projects')
        .update(payload)
        .eq('id', editingId)

      if (error) return console.error(error)

      setProjects((prev) =>
        prev.map((p) =>
          p.id === editingId ? { ...p, ...payload } : p
        )
      )

      setEditingId(null)
    } else {
      const { data, error } = await supabase
        .from('projects')
        .insert([payload])
        .select()

      if (error) return console.error(error)

      if (data) setProjects((prev) => [...prev, ...data])
    }

    setForm(emptyForm)
  }

  async function togglePublic(id: string, current: boolean) {
    const { error } = await supabase
      .from('projects')
      .update({ is_public: !current })
      .eq('id', id)

    if (error) return console.error(error)

    setProjects((prev) =>
      prev.map((p) =>
        p.id === id ? { ...p, is_public: !current } : p
      )
    )
  }

  async function deleteProject(id: string) {
    if (!confirm('Poistetaanko projekti?')) return

    const { error } = await supabase
      .from('projects')
      .delete()
      .eq('id', id)

    if (error) return console.error(error)

    setProjects((prev) => prev.filter((p) => p.id !== id))
  }

  function startEdit(project: Project) {
    setEditingId(project.id)
    setForm({
      ...project,
      apartments: project.apartments || '',
      floor_area: project.floor_area || '',
      estimated_cost: project.estimated_cost || '',
      construction_start: project.construction_start || '',
    })
  }

  if (loading) return <p>Ladataan...</p>

  return (
    <div style={{ padding: 20, maxWidth: 900 }}>
      <h1>Dashboard – Hallinta</h1>

      <form onSubmit={handleSubmit} style={{ marginBottom: 40 }}>
        <h3>{editingId ? 'Muokkaa projektia' : 'Lisää projekti'}</h3>

        <input placeholder="Projektin nimi" value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })} />

        <input placeholder="Sijainti / Osoite" value={form.location}
          onChange={(e) => setForm({ ...form, location: e.target.value })} />

        <input placeholder="Kaupunki" value={form.city}
          onChange={(e) => setForm({ ...form, city: e.target.value })} />

        <input placeholder="Vaihe" value={form.phase}
          onChange={(e) => setForm({ ...form, phase: e.target.value })} />

        <input placeholder="🏗️ Rakennuttaja" value={form.developer}
          onChange={(e) => setForm({ ...form, developer: e.target.value })} />

        <input placeholder="👷 Rakennusliike" value={form.builder}
          onChange={(e) => setForm({ ...form, builder: e.target.value })} />

        <input placeholder="🏢 Kohde" value={form.property_type}
          onChange={(e) => setForm({ ...form, property_type: e.target.value })} />

        <input placeholder="🏠 Asuntoja" value={form.apartments}
          onChange={(e) => setForm({ ...form, apartments: e.target.value })} />

        <input placeholder="📐 Kerrosala" value={form.floor_area}
          onChange={(e) => setForm({ ...form, floor_area: e.target.value })} />

        <input placeholder="💰 Arvioitu kustannus" value={form.estimated_cost}
          onChange={(e) => setForm({ ...form, estimated_cost: e.target.value })} />

        <input type="date" value={form.construction_start}
          onChange={(e) => setForm({ ...form, construction_start: e.target.value })} />

        <input placeholder="Rakennesuunnittelu" value={form.structural_design}
          onChange={(e) => setForm({ ...form, structural_design: e.target.value })} />

        <input placeholder="LVIA-suunnittelu" value={form.hvac_design}
          onChange={(e) => setForm({ ...form, hvac_design: e.target.value })} />

        <input placeholder="Sähkösuunnittelu" value={form.electrical_design}
          onChange={(e) => setForm({ ...form, electrical_design: e.target.value })} />

        <input placeholder="Arkkitehtisuunnittelu" value={form.architectural_design}
          onChange={(e) => setForm({ ...form, architectural_design: e.target.value })} />

        <input placeholder="Pohjarakennesuunnittelu" value={form.geotechnical_design}
          onChange={(e) => setForm({ ...form, geotechnical_design: e.target.value })} />

        <input placeholder="Maanrakentaja" value={form.earthworks_contractor}
          onChange={(e) => setForm({ ...form, earthworks_contractor: e.target.value })} />

        <textarea placeholder="Lisätietoja" value={form.additional_info}
          onChange={(e) => setForm({ ...form, additional_info: e.target.value })} />

        <label>
          <input type="checkbox" checked={form.is_public}
            onChange={(e) => setForm({ ...form, is_public: e.target.checked })} />
          Näytä julkisesti
        </label>

        <br />
        <button type="submit">
          {editingId ? 'Päivitä projekti' : 'Lisää projekti'}
        </button>
      </form>

      {projects.map((p) => (
        <div key={p.id} style={{ border: '1px solid #ccc', padding: 15, marginBottom: 20 }}>
          <h3>{p.name}</h3>
          <p><strong>Kaupunki:</strong> {p.city}</p>
          <p><strong>Vaihe:</strong> {p.phase}</p>
          <p><strong>Näkyvyys:</strong> {p.is_public ? '🟢 Julkinen' : '🔒 Piilotettu'}</p>

          <button onClick={() => togglePublic(p.id, p.is_public)}>
            {p.is_public ? 'Piilota' : 'Julkaise'}
          </button>

          <button onClick={() => startEdit(p)} style={{ marginLeft: 10 }}>
            Muokkaa
          </button>

          <button onClick={() => deleteProject(p.id)}
            style={{ marginLeft: 10, background: 'red', color: 'white' }}>
            Poista
          </button>
        </div>
      ))}
    </div>
  )
}