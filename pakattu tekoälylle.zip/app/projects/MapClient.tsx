'use client'

import { useEffect } from 'react'
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet'
import L from 'leaflet'

type Project = {
  id: string
  name: string
  city: string
  phase: string
  latitude: number | null
  longitude: number | null
}

export default function MapClient({ projects }: { projects: Project[] }) {
  useEffect(() => {
    // Fix marker icons Next.js:ssä
    delete (L.Icon.Default.prototype as any)._getIconUrl
    L.Icon.Default.mergeOptions({
      iconRetinaUrl:
        'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon-2x.png',
      iconUrl:
        'https://unpkg.com/leaflet@1.7.1/dist/images/marker-icon.png',
      shadowUrl:
        'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
    })
  }, [])

  const projectsWithCoords = projects.filter((p) => p.latitude && p.longitude)

  return (
    <div style={{ height: 500, marginBottom: 40 }}>
      <MapContainer
        center={[60.1699, 24.9384]}
        zoom={6}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution="&copy; OpenStreetMap contributors"
        />

        {projectsWithCoords.map((p) => (
          <Marker key={p.id} position={[p.latitude!, p.longitude!]}>
            <Popup>
              <strong>{p.name}</strong>
              <br />
              {p.city}
              <br />
              {p.phase}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  )
}