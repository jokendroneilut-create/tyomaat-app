'use client'

import { useEffect, useState } from 'react'
import { supabase } from '@/lib/supabaseClient'
import Map from './Map'

type Project = {
  id: string
  name: string
  city: string
  phase: string
  location: string | null
  developer: string | null
  builder: string | null
  property_type: string | null
  apartments: number | null
  floor_area: number | null
  estimated_cost: number | null
  construction_start: string | null
  structural_design: string | null
  hvac_design: string | null
  electrical_design: string | null
  architectural_design: string | null
  geotechnical_design: string | null
  earthworks_contractor: string | null
  additional_info: string | null
  latitude: number | null
  longitude: number | null
}

export default function Projects() {
  const [projects, setProjects] = useState<Project[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchProjects = async () => {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .eq('is_public', true)

      if (error) {
        console.error(error)
      } else {
        setProjects(data || [])
      }

      setLoading(false)
    }

    fetchProjects()
  }, [])

  if (loading) return <p style={{ padding: 20 }}>Ladataan...</p>

  return (
    <div style={{ padding: 20, maxWidth: 1000, margin: '0 auto' }}>
      <h1 style={{ marginBottom: 30 }}>Työmaat</h1>

      {/* 🗺 Kartta (wrapper tekee ssr:false) */}
      <Map projects={projects} />

      {/* 📋 Lista */}
      {projects.length === 0 && <p>Ei projekteja vielä.</p>}

      {projects.map((project) => (
        <div
          key={project.id}
          style={{
            border: '1px solid #ddd',
            padding: 20,
            marginBottom: 20,
            borderRadius: 10,
            background: '#fff',
          }}
        >
          <h2 style={{ marginBottom: 10 }}>{project.name}</h2>

          <p><strong>Sijainti:</strong> {project.location || '-'}</p>
          <p><strong>Kaupunki:</strong> {project.city}</p>
          <p><strong>Vaihe:</strong> {project.phase}</p>

          <hr style={{ margin: '15px 0' }} />

          <p><strong>🏗️ Rakennuttaja:</strong> {project.developer || '-'}</p>
          <p><strong>👷 Rakennusliike:</strong> {project.builder || '-'}</p>
          <p><strong>🏢 Kohde:</strong> {project.property_type || '-'}</p>
          <p><strong>🏠 Asuntoja:</strong> {project.apartments ?? '-'}</p>
          <p>
            <strong>📐 Kerrosala:</strong>{' '}
            {project.floor_area ? `${project.floor_area} m²` : '-'}
          </p>
          <p>
            <strong>💰 Arvioitu kustannus:</strong>{' '}
            {project.estimated_cost ? `${project.estimated_cost} €` : '-'}
          </p>
          <p>
            <strong>📅 Rakentamisen aloitus:</strong>{' '}
            {project.construction_start || '-'}
          </p>

          <hr style={{ margin: '15px 0' }} />

          <p><strong>Rakennesuunnittelu:</strong> {project.structural_design || '-'}</p>
          <p><strong>LVIA-suunnittelu:</strong> {project.hvac_design || '-'}</p>
          <p><strong>Sähkösuunnittelu:</strong> {project.electrical_design || '-'}</p>
          <p><strong>Arkkitehtisuunnittelu:</strong> {project.architectural_design || '-'}</p>
          <p><strong>Pohjarakennesuunnittelu:</strong> {project.geotechnical_design || '-'}</p>
          <p><strong>Maanrakentaja:</strong> {project.earthworks_contractor || '-'}</p>

          {project.additional_info && (
            <>
              <hr style={{ margin: '15px 0' }} />
              <p><strong>Lisätietoja:</strong></p>
              <p>{project.additional_info}</p>
            </>
          )}
        </div>
      ))}
    </div>
  )
}